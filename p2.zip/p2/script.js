const form = document.getElementById('registrationForm');
const formSection = document.getElementById('formSection');
const listSection = document.getElementById('listSection');
const tbody = document.querySelector("#userTable tbody");

let users = JSON.parse(localStorage.getItem("users")) || [];

function showForm() {
  formSection.style.display = "block";
  listSection.style.display = "none";
}

function showList() {
  formSection.style.display = "none";
  listSection.style.display = "block";
  renderUserList();
}

form.addEventListener('submit', function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const user = { name, email, password };

  users.push(user);
  localStorage.setItem("users", JSON.stringify(users));

  const xhr = new XMLHttpRequest();
  xhr.open("POST", "https://jsonplaceholder.typicode.com/posts", true);
  xhr.setRequestHeader("Content-Type", "application/json");

  xhr.onload = function () {
    if (xhr.status === 201) {
      alert("User registered and data sent successfully!");
      form.reset();
    } else {
      alert("Failed to send data.");
    }
  };

  xhr.send(JSON.stringify(user));
});

function renderUserList() {
  tbody.innerHTML = "";
  users.forEach(user => {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${user.name}</td><td>${user.email}</td>`;
    tbody.appendChild(row);
  });
}
